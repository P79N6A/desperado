<?php 
$OC_Version = array(11,0,8,1);
$OC_VersionString = '11.0.8';
$OC_Edition = '';
$OC_Channel = 'stable';
$OC_VersionCanBeUpgradedFrom = array (
  'nextcloud' => 
  array (
    '9.1' => true,
    '11.0' => true,
  ),
  'owncloud' => 
  array (
    '9.1' => true,
  ),
);
$OC_Build = '2018-03-13T19:17:27+00:00 bd9f5e6d1ec3677e1aa7b72112b990b86de2f117';
$vendor = 'nextcloud';
