<?php 
$OC_Version = array(15,0,7,0);
$OC_VersionString = '15.0.7';
$OC_Edition = '';
$OC_Channel = 'stable';
$OC_VersionCanBeUpgradedFrom = array (
  'nextcloud' => 
  array (
    '14.0' => true,
    '15.0' => true,
  ),
  'owncloud' => 
  array (
  ),
);
$OC_Build = '2019-04-08T21:25:55+00:00 e578672704cc159694dc2cd8e77c208ae84b35d6';
$vendor = 'nextcloud';
