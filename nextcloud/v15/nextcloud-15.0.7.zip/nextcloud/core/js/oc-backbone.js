/*
 * Copyright (c) 2015
 *
 * This file is licensed under the Affero General Public License version 3
 * or later.
 *
 * See the COPYING-README file.
 *
 */

/* global Backbone */
if(!_.isUndefined(Backbone)) {
	OC.Backbone = Backbone.noConflict();
}
