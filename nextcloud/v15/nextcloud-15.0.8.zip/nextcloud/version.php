<?php 
$OC_Version = array(15,0,8,1);
$OC_VersionString = '15.0.8';
$OC_Edition = '';
$OC_Channel = 'stable';
$OC_VersionCanBeUpgradedFrom = array (
  'nextcloud' => 
  array (
    '14.0' => true,
    '15.0' => true,
  ),
  'owncloud' => 
  array (
  ),
);
$OC_Build = '2019-05-15T13:01:42+00:00 0ca9141de4eaf3ca147ffaedfaee0157166f643c';
$vendor = 'nextcloud';
