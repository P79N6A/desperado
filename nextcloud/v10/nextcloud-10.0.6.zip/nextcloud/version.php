<?php 
$OC_Version = array(9,1,6,1);
$OC_VersionString = '10.0.6';
$OC_Edition = '';
$OC_Channel = 'stable';
$OC_VersionCanBeUpgradedFrom = array (
  0 => 9,
  1 => 0,
);
$OC_Build = '2017-08-06T18:45:03+00:00 cf82aa3f3081ef3920bdcad9c848d36b1d11001b';
$vendor = 'nextcloud';
